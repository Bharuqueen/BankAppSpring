import { TestBed } from '@angular/core/testing';

import { DiscountserviceService } from './discountservice.service';

describe('DiscountserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DiscountserviceService = TestBed.get(DiscountserviceService);
    expect(service).toBeTruthy();
  });
});
