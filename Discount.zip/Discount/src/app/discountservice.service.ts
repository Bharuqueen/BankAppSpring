import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class DiscountserviceService {

  constructor(private httpClient:HttpClient) { }


  
  showdiscount(prodId:string):Observable<number>
    {
    let url = 'http://localhost:8081/showdiscount/'+prodId;    
    return this.httpClient.get<number>(url);    
  }

  discount(prodId:string):Observable<number>
    {
    let url = 'http://localhost:8081/discount/'+prodId;    
    return this.httpClient.get<number>(url);    
  }

  mrp(prodId:string):Observable<number>
    {
    let url = 'http://localhost:8081/mrp/'+prodId;    
    return this.httpClient.get<number>(url);    
  }

}
