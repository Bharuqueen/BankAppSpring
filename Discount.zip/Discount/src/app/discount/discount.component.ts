import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DiscountserviceService } from '../discountservice.service';
import { Product } from '../product';

@Component({
  selector: 'app-discount',
  templateUrl: './discount.component.html',
  styleUrls: ['./discount.component.css']
})
export class DiscountComponent implements OnInit {
  Prod:Product;
  show:number;
  discount:number;
  mrp:number;

  constructor(private router: Router, private service: DiscountserviceService) { 
    this.Prod =new Product();
  }
  calDiscount(prodId)
   {
      this.service.showdiscount(prodId).subscribe(data=>{
        this.show=data;
      })
      this.service.discount(prodId).subscribe(data=>{
        this.discount=data;      
    })
    this.service.mrp(prodId).subscribe(data=>{
      this.mrp=data;      
  })
    }
       


  ngOnInit() {
  
    }
 
}
