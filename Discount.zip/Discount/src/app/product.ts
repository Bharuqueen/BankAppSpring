export class Product {
    prodId:String;
    prodName:String;
    ProdCategory:String;
    Price:number;
    discount:number;
    validTime:String;
    promocode:String;
    viewscount:number;
    qty:number;
    merchant:String;
    productRating:String;

}
