package com.service;

import java.util.Random;

import com.bean.Order;

public class ServiceOrder{
	

//calculating the Order amount in INR.
	public int calculateOrder(Order bean) {
		int Orderamount=0;
		Orderamount=(int)(bean.getPrice()*75);
		return Orderamount;
	}
		
		
		
		
		// TODO Auto-generated method stub
	
//calculating the total amount of currency conversion charges.

	public void  SaveOrder(Order order)
	{
		double total=0;
		double conversion=(1.25/100.0)*order.getCharges();
		total=order.getQuantity()*conversion;
		order.setAmount(total);
		Random rand=new Random();
		int id=rand.nextInt(10);
		order.setId(id);
		
	}
		
//overriding methods of saveOrder.
	public int saveOrder(Order bean) {
		// TODO Auto-generated method stub
		return 0;
	}

}

