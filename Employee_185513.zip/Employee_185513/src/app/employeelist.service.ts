import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable} from 'rxjs';
import { Iemployee} from './iemployee';


@Injectable({
  providedIn: 'root'
})
export class EmployeelistService {
  
  employee:Iemployee[]=[];

  constructor(private http:HttpClient) { }

getEmployee():Observable<Iemployee[]>
 {
   //  //getting data from json
return  this.http.get<Iemployee[]>('./assets/emp.json');
}

addEmployee(emp)
{
   this.employee.push(emp);

}
get(){
  return this.employee;
}
}

