import { Component, OnInit } from '@angular/core';
import { EmployeelistService } from '../employeelist.service';




@Component({
  selector: 'app-listallemployees',
  templateUrl: './listallemployees.component.html',
  styleUrls: ['./listallemployees.component.css']
})
export class ListallemployeesComponent implements OnInit {
  employee: any;
  

  constructor(private employeelistservice:EmployeelistService) { }

  ngOnInit() {
    this.employeelistservice.getEmployee().subscribe((data)=>{ 
      this.employee=data
    let a=this.employeelistservice.get();
    // the below method is used to add all details in the table when we save the details
    for(let emp of a)
    {
      this.employee.push(emp);
    }
   });
  }
  //delete method is to delete the entire row when delete is clicked.
   Delete(emp){
    let index = this.employee.indexOf(emp);
        this.employee.splice(index,1);
      }
}


