import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListallemployeesComponent } from './listallemployees.component';

describe('ListallemployeesComponent', () => {
  let component: ListallemployeesComponent;
  let fixture: ComponentFixture<ListallemployeesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListallemployeesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListallemployeesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
