export interface Iemployee {
    id:number;
    name:string;
    email:string;
    phone:number

}
