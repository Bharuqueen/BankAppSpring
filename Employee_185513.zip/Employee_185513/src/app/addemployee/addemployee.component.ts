import { Component, OnInit } from '@angular/core';
import { Iemployee } from '../iemployee';
import { EmployeelistService } from '../employeelist.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addemployee',
  templateUrl: './addemployee.component.html',
  styleUrls: ['./addemployee.component.css']
})
export class AddemployeeComponent implements OnInit {
  employee: Iemployee[]=[];

  constructor(private employeelistservice:EmployeelistService,private router:Router) { }

  ngOnInit() {
    this.employeelistservice.getEmployee().subscribe((data)=>this.employee=data);
  
  }
  //submit method to the all details and save

  onSubmit(form:Iemployee){
    this.employeelistservice.addEmployee(form);// add employee method is called present in service layer.
        this.router.navigate(['/emplist']); 
    }
}


