import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListallemployeesComponent } from './listallemployees/listallemployees.component';
import { AddemployeeComponent } from './addemployee/addemployee.component';


const routes: Routes = [
  {path:'emplist',component:ListallemployeesComponent},
  {path:'addemp',component: AddemployeeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
