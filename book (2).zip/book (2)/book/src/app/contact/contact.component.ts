import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BookService } from '../book.service';
import { Book } from '../Book';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  bookService: any;
  book: any;
  errorMessage: any;
  product: Book;

  constructor(private route:ActivatedRoute, bookService:BookService) { }

  ngOnInit() {
    const param =this.route.snapshot.paramMap.get('name');
    if(param) {
      const name=+param;
      this.getProduct(name);
    }
  }
    getProduct(name)
  {
    this.bookService.getProduct(name).subscribe(
      product=>this.book=product,
      error=>this.errorMessage=<any>error);
  }
}
  


