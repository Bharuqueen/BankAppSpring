package com.service;

public class ValidationClass {
	public static boolean Validquantity(int quantity)
	{
	try
	{
		if(quantity<1)
		{
			throw new Exception("quantity is less than one");
		}
		else
			System.out.println("qunatity should be greater than one");
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	
	return false;

	}
}

