package com.bean;

import java.util.Scanner;

import com.service.ValidationClass;

//initialize and set all variables.
public class Order {
	private int id;
	private String product; 
	private double price;
	private int quantity;
	private double amount;
	private double charges;
	

	

	public Order(int id, String product, double price, int quantity, double amount, double charges) {
		super();
		this.id = id;
		this.product = product;
		this.price = price;
		this.quantity = quantity;
		this.amount = amount;
		this.charges = charges;
	}



	//setters,  getters are to set them and get them.

	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getProduct() {
		return product;
	}



	public void setProduct(String product) {
		this.product = product;
	}



	public double getPrice() {
		return price;
	}



	public void setPrice(double price) {
		this.price = price;
	}



	public int getQuantity() {
		return quantity;
	}


//it calls the  method in ValidationClass.

	public void setQuantity(int quantity) {
		Scanner sc=new Scanner(System.in);
		
		if(ValidationClass.Validquantity(quantity))
		{
		this.quantity = quantity;
		}
		
		else
			System.out.println("enter correct qunatity");
		setQuantity(sc.nextInt());
	}


	public double getAmount() {
		return amount;
	}



	public void setAmount(double amount) {
		this.amount = amount;
	}



	public double getCharges() {
		return charges;
	}



	public void setCharges(double charges) {
		this.charges = charges;
	}

//to string to display the details.
	@Override
	public String toString() {
		return "Order [id=" + id + ", product=" + product + ", price=" + price + ", quantity=" + quantity + ", amount="
				+ amount + ", charges=" + charges + "]";
	}
}
	