import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Iproduct } from '../iproduct';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  someMessage:string;
  products:Iproduct[];
  errorMessage:string="";
  filteredproducts: any;
  getproducts: any;
  constructor(private productservice: ProductService) { }
  
  

  onRatingClicked(message)
      {
        this.someMessage=message
      }

  ngOnInit():void {
   
    this.productservice.getproducts().subscribe(
      products=> {
        this.products=products;
        this.filteredproducts=this.products;
      }
      
    );
    }
   

  }




