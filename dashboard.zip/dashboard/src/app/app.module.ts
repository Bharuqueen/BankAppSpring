import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';

// import { AppRoutingModule } from './app-routing.module';
// import { AppComponent } from './app.component';
// import { MywelcomeComponent } from './mywelcome/mywelcome.component';
// import { HerolistComponent } from './herolist/herolist.component';
// import { ProductListComponent } from './product-list/product-list.component';
// import { StarComponent } from './star/star.component';
// import { WelcomeComponent } from './welcome/welcome.component';
// import { ProductDetailsComponent } from './product-details/product-details.component';
// import { ProductFilterPipe } from './product-filter.pipe';
// import { FormsModule } from '@angular/forms';
// import { HttpClientModule } from '@angular/common/http';


@NgModule({
  declarations: [
    // AppComponent,
    // MywelcomeComponent,
    // HerolistComponent,
    // ProductListComponent,
    // StarComponent,
    // WelcomeComponent,
    // ProductDetailsComponent,
    // ProductFilterPipe
  ],
  imports: [
     BrowserModule,
    // AppRoutingModule,
    // FormsModule,
    // HttpClientModule
    
    
  ],
  providers: [],

})
export class AppModule { }
