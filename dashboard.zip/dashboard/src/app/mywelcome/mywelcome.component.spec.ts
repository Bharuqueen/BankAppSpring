import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MywelcomeComponent } from './mywelcome.component';

describe('MywelcomeComponent', () => {
  let component: MywelcomeComponent;
  let fixture: ComponentFixture<MywelcomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MywelcomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MywelcomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
