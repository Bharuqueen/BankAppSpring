import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-star',
  templateUrl: './star.component.html',
  styleUrls: ['./star.component.css']
})
export class StarComponent implements OnInit {
  @Input()starrating:number;
  @Output() ratingClicked:EventEmitter<string>=new EventEmitter<string>();
  someMessage:string;
 
  starWidth: number;
  rate: number;

  constructor() { }

  ngOnInit() {
  
  }
  ngOnChanges(){
   
   this.rate=this.starrating;
    this.starWidth=this.rate*15;
  }
    onClick() {
      this.ratingClicked.emit("You have clicked on "+this.starrating + "Star");
      
    }
  
  
  }
    


