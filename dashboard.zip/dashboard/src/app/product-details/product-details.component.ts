import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProductService } from '../product.service';
import { Iproduct } from '../iproduct';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {
  errorMessage: any;
  products: Iproduct;
  product: Iproduct;
  

  constructor(private route:ActivatedRoute,private productservice: ProductService) { }

  ngOnInit() {
    const param =this.route.snapshot.paramMap.get('id');
    if(param) {
      const id=+param;
      this.getProduct(id);
    }
  }
    getProduct(id)
  {
    this.productservice.getproduct(id).subscribe(
      product=>this.products=product,
      error=>this.errorMessage=<any>error);
  }
}


