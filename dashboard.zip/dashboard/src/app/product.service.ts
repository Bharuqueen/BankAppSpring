import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Iproduct } from './iproduct';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  
  private productUrl='./assets/products.json';
  constructor(private http:HttpClient) { }
    
    getproducts(): Observable<Iproduct[]> {
      return this.http.get<Iproduct[]>(this.productUrl);
    }
    getproduct(id:Number):
    Observable<Iproduct | undefined>{
      return this.getproducts().pipe(map((products:Iproduct[])=>products.find(p=>p.productId===id))
      );
    }


  }

