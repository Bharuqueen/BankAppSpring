interface Employee{
    firstName:string;
    lastName:string;
    age:number;

}
let employee:any={
    firstName:"bharu",
    lastName:"sri",
    age:21
}
console.log(employee);