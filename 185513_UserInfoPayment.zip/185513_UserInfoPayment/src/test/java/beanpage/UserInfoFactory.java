package beanpage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class UserInfoFactory {
WebDriver driver;


 @FindBy(name="txtNM")
 @CacheLookup
 WebElement Applicantname;
   
	
	//step 1 : identify elements
	@FindBy(name="txtFN")
	@CacheLookup
	WebElement firstName;
	
	
	
	@FindBy(name="txtFtName")
	@CacheLookup
	WebElement fatherName;
	
	
	@FindBy(xpath="//*[@id='txtDOB']")
	@CacheLookup
	WebElement Dateofbirth;
	
	@FindBy(name="rdbFML")
	@CacheLookup
	WebElement Gender;
	
	
	@FindBy(name="txtMNo")
	@CacheLookup
	WebElement mobileNo;
	
	@FindBy(how=How.NAME, using="txtEmailID")
	@CacheLookup
	WebElement email;

	@FindBy(how=How.NAME, using="txtLLine" )
	@CacheLookup
	WebElement landline;
	
	@FindBy(how=How.NAME, using="rdbRAddress")
	@CacheLookup
	WebElement Communicaton;
	
	
	
	@FindBy(how=How.NAME, using="resAddress")
	@CacheLookup
	WebElement ResidenceAddres;

	
	//using how class
		@FindBy(how=How.ID, using="btnSubmit")
		@CacheLookup
		WebElement confirmButton;
	

	public WebDriver getDriver() {
		return driver;
	}
	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}
	public void setApplicantName(String 	Applicantname) {
		this.Applicantname.sendKeys(	Applicantname);
	}
	public WebElement getApplicantName() {
		return Applicantname;
	}
	
	public WebElement getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}
	public void setFatherName(String fatherName ) {
		this.fatherName.sendKeys(fatherName);
	}
	public void setDateofBirth(String Dateofbirth) {
		this.Dateofbirth.sendKeys(Dateofbirth);
	}
	public WebElement getDateofBirth() {
		return Dateofbirth;
	}
	public void setGender(String Gender) {
		this.Gender.sendKeys(Gender);
	}
	public WebElement getGender() {
		return Gender;
	}
	
	public WebElement getFatherName() {
		return fatherName;
	}
	
	public WebElement getConfirmButton() {
		return confirmButton;
	}
	public void setConfirmButton() {
		this.confirmButton.click();
	}
	
	public WebElement getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email.sendKeys(email);
	}
	public WebElement getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo.sendKeys(mobileNo);
	}
	public void setLandLine(String landline) {
		this.landline.sendKeys(landline);
	}
	public WebElement getLandLine() {
		return landline;
	}
	public void setCommunication(String Communicaton) {
		this.Communicaton.sendKeys(Communicaton);
	}
	public WebElement getCommunication() {
		return Communicaton ;
	}
	public void setResidenceAddres(String ResidenceAddres) {
		this.ResidenceAddres.sendKeys(ResidenceAddres);
	}
	public WebElement getResidenceAddres() {
		return ResidenceAddres;
	}
	
	
	
  //initiating Elements
	public UserInfoFactory (WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}


	
	
	

}
