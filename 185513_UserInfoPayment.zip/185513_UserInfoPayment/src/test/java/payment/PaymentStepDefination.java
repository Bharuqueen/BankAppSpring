package payment;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import beanpage.PaymentFactory;
import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class PaymentStepDefination {
	private WebDriver driver;
	private PaymentFactory  payment;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\srsathi\\Desktop\\chromedriver_win32\\chromedriver.exe" );
		driver= new ChromeDriver();
		}

@Given("^user is on 'Payment Details' page$")
public void user_is_on_Payment_Details_page() throws Throwable {
	driver.get("file:///C:/Users/srsathi/Desktop/details/UserInfoPayment/PaymentDetails.html");
    throw new PendingException();
}

@When("^user enters loads the page$")
public void user_enters_loads_the_page() throws Throwable {
    
}

@Then("^valid page should open$")
public void valid_page_should_open() throws Throwable {
	String expectedPageTitle="Payment Details";
	String actualPageTitle=driver.getTitle();
	Assert.assertEquals(expectedPageTitle, actualPageTitle);
	driver.close();
    throw new PendingException();
}

@When("^user enters invalid name$")
public void user_enters_invalid_name() throws Throwable {
	payment.setName("");
	payment. clickPaymentButton();
    throw new PendingException();
}

@Then("^displays 'Please fill the Card holder name'$")
public void displays_Please_fill_the_Card_holder_name() throws Throwable {
	String expectedMessage="Please fill the Card holder name";
	String actualMessage=driver.switchTo().alert().getText();
	if(expectedMessage.equals(actualMessage)) {
        System.out.println("Matched");
    }
    else {
        System.out.println("Unmatched");
    }
	driver.switchTo().alert().accept();
	driver.close();
    throw new PendingException();
}

@When("^user enters invalid Debit Card Number$")
public void user_enters_invalid_Debit_Card_Number() throws Throwable {
	payment.setName("Nikki");
	payment.setCardNumber("");
	payment. clickPaymentButton();
    throw new PendingException();
}

@Then("^displays 'Please fill the Debit card Number'$")
public void displays_Please_fill_the_Debit_card_Number() throws Throwable {
	String expectedMessage="Please fill the Debit card Number";
	String actualMessage=driver.switchTo().alert().getText();
	if(expectedMessage.equals(actualMessage)) {
        System.out.println("Matched");
    }
    else {
        System.out.println("Unmatched");
    }
	driver.switchTo().alert().accept();
	driver.close();
    throw new PendingException();
}

@When("^user enters invalid expiration month$")
public void user_enters_invalid_expiration_month() throws Throwable {
	payment.setName("Nikki");
	payment.setCardNumber("9928282558525");
	payment.setExpirationMonth("");
	payment. clickPaymentButton();
    throw new PendingException();
}

@Then("^displays 'Please fill expiration month'$")
public void displays_Please_fill_expiration_month() throws Throwable {
	String expectedMessage="Please fill the expiration month ";
	String actualMessage=driver.switchTo().alert().getText();
	if(expectedMessage.equals(actualMessage)) {
        System.out.println("Matched");
    }
    else {
        System.out.println("Unmatched");
    }
	driver.switchTo().alert().accept();
	driver.close();
    throw new PendingException();
}

@When("^user enters invalid expiration year$")
public void user_enters_invalid_expiration_year() throws Throwable {
	payment.setName("Nishitha");
	payment.setCardNumber("9928282558525");
	payment.setExpirationMonth("08");
	payment.setExpiartionYear("");
	payment. clickPaymentButton();
	
    throw new PendingException();
}

@Then("^displays 'Please fill the expiration year'$")
public void displays_Please_fill_the_expiration_year() throws Throwable {
	String expectedMessage="Please fill the expiration year";
	String actualMessage=driver.switchTo().alert().getText();
	if(expectedMessage.equals(actualMessage)) {
        System.out.println("Matched");
    }
    else {
        System.out.println("Unmatched");
    }
	driver.switchTo().alert().accept();
	driver.close();
    throw new PendingException();
}

@When("^user enters valid  payment details$")
public void user_enters_valid_payment_details() throws Throwable {
	payment.setName("Nishitha");
	payment.setCardNumber("9928282558525");
	payment.setExpirationMonth("08");
	payment.setExpiartionYear("23");
	payment. clickPaymentButton();
    throw new PendingException();
}

@Then("^displays 'Pan Card Registration Done successfully!!!'$")
public void displays_Pan_Card_Registration_Done_successfully() throws Throwable {
	String expectedMessage=" Pan Card Registration done successfully done!!!";
	String actualMessage=driver.switchTo().alert().getText();
	if(expectedMessage.equals(actualMessage)) {
        System.out.println("Matched");
    }
    else {
        System.out.println("Unmatched");
    }
	driver.switchTo().alert().accept();
	driver.close();
    throw new PendingException();
}



}
