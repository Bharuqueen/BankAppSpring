package payment;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="C:\\Users\\srsathi\\Desktop\\stsworkspace\\185513_UserInfoPayment\\src\\test\\resources\\PaymentDetails\\PaymentDetails.feature")
public class StepRunner {

}
