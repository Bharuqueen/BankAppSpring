package userinfo;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import beanpage.UserInfoFactory;
import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class UserInfoStepDefination {
	private WebDriver driver;
	UserInfoFactory userinfo;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\srsathi\\Desktop\\chromedriver_win32\\chromedriver.exe" );
		
		driver= new ChromeDriver();
	}

@Given("^user is on 'PAN CARD User Information' page$")
public void user_is_on_PAN_CARD_User_Information_page() throws Throwable {

	driver.get("file:///C:/Users/srsathi/Desktop/details/UserInfoPayment/UserInformation.html");
	
	//	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	userinfo = new UserInfoFactory(driver);
    throw new PendingException();
}

@When("^user enters invalid Applicant name$")
public void user_enters_invalid_Applicant_name() throws Throwable {
	userinfo.setApplicantName("");
	userinfo.setConfirmButton();
    throw new PendingException();
}

@Then("^displays 'Please fill the Applicant Name'$")
public void displays_Please_fill_the_Applicant_Name() throws Throwable {
	String expectedMessage="Please fill the Applicant Name";
	String actualMessage=driver.switchTo().alert().getText();
	if(expectedMessage.equals(actualMessage)) {
        System.out.println("Matched");
    }
    else {
        System.out.println("Unmatched");
    }
	driver.switchTo().alert().accept();
	driver.close();
    throw new PendingException();
}

@When("^user enters invalid first name$")
public void user_enters_invalid_first_name() throws Throwable {
	userinfo.setApplicantName("Bharathi");
	userinfo.setFirstName("");
	userinfo.setConfirmButton();
    throw new PendingException();
}

@Then("^displays 'Please fill the First Name'$")
public void displays_Please_fill_the_First_Name() throws Throwable {
	String expectedMessage="Please fill the First Name";
	String actualMessage=driver.switchTo().alert().getText();
	if(expectedMessage.equals(actualMessage)) {
        System.out.println("Matched");
    }
    else {
        System.out.println("Unmatched");
    }
	driver.switchTo().alert().accept();
	driver.close();
    throw new PendingException();
}

/*@When("^user enters invalid last name$")
public void user_enters_invalid_last_name() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Then("^displays 'Please fill the Last Name'$")
public void displays_Please_fill_the_Last_Name() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}
*/

@When("^user enters invalid father name$")
public void user_enters_invalid_father_name() throws Throwable {
	userinfo.setApplicantName("Bharathi");
	userinfo.setFirstName("Bharathi");
	userinfo.setFatherName("");
	userinfo.setConfirmButton();
    throw new PendingException();
}

@Then("^displays 'Please fill the Father Name'$")
public void displays_Please_fill_the_Father_Name() throws Throwable {
	String expectedMessage="Please fill the Father Name";
	String actualMessage=driver.switchTo().alert().getText();
	if(expectedMessage.equals(actualMessage)) {
        System.out.println("Matched");
    }
    else {
        System.out.println("Unmatched");
    }
	driver.switchTo().alert().accept();
	driver.close();
}

@When("^user enters invalid DOB$")
public void user_enters_invalid_DOB() throws Throwable {
	userinfo.setApplicantName("Bharathi");
	userinfo.setFirstName("Bharathi");
	userinfo.setFatherName("Krishna");
	userinfo.setDateofBirth("");
	userinfo.setConfirmButton();
    throw new PendingException();
}

@Then("^display 'Please fill the DOB'$")
public void display_Please_fill_the_DOB() throws Throwable {
	String expectedMessage="Please fill the DOB";
	String actualMessage=driver.switchTo().alert().getText();
	if(expectedMessage.equals(actualMessage)) {
        System.out.println("Matched");
    }
    else {
        System.out.println("Unmatched");
    }
	driver.switchTo().alert().accept();
	driver.close();
    throw new PendingException();
}
/*
@When("^user enters invalid Date$")
public void user_enters_invalid_Date() throws Throwable {
    
    throw new PendingException();
}

@Then("^display 'Please Enter valid date\\(dd-MM-yyyy\\)'$")
public void display_Please_Enter_valid_date_dd_MM_yyyy() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}*/

@When("^user enters invalid Gender$")
public void user_enters_invalid_Gender() throws Throwable {
	userinfo.setApplicantName("Bharathi");
	userinfo.setFirstName("Bharathi");
	userinfo.setFatherName("Krishna");
	userinfo.setDateofBirth("jan");
	userinfo.setGender("");
	userinfo.setConfirmButton();
    throw new PendingException();
}

@Then("^display 'Please select the Gender'$")
public void display_Please_select_the_Gender() throws Throwable {
	String expectedMessage="Please select the Gender";
	String actualMessage=driver.switchTo().alert().getText();
	if(expectedMessage.equals(actualMessage)) {
        System.out.println("Matched");
    }
    else {
        System.out.println("Unmatched");
    }
	driver.switchTo().alert().accept();
	driver.close();
    throw new PendingException();
}

@When("^user enters invalid mobile number$")
public void user_enters_invalid_mobile_number() throws Throwable {
	userinfo.setApplicantName("Bharathi");
	userinfo.setFirstName("Bharathi");
	userinfo.setFatherName("Krishna");
	userinfo.setDateofBirth("15-11-1997");
	userinfo.setGender("Female");
	userinfo.setMobileNo("");
	userinfo.setConfirmButton();
    throw new PendingException();
}

@Then("^display 'Please fill Mobile No\\.'$")
public void display_Please_fill_Mobile_No() throws Throwable {
	String expectedMessage="Please fill Mobile No";
	String actualMessage=driver.switchTo().alert().getText();
	if(expectedMessage.equals(actualMessage)) {
        System.out.println("Matched");
    }
    else {
        System.out.println("Unmatched");
    }
	driver.switchTo().alert().accept();
	driver.close();
    throw new PendingException();
}

@When("^user enters wrong mobile number$")
public void user_enters_wrong_mobile_number() throws Throwable {
	userinfo.setApplicantName("Bharathi");
	userinfo.setFirstName("Bharathi");
	userinfo.setFatherName("Krishna");
	userinfo.setDateofBirth("15-11-1997");
	userinfo.setGender("Female");
	userinfo.setMobileNo("2345");
	userinfo.setConfirmButton();
    throw new PendingException();
}

@Then("^display 'Please enter valid mobile no'$")
public void display_Please_enter_valid_mobile_no() throws Throwable {
	String expectedMessage="Please enter valid mobile no";
	String actualMessage=driver.switchTo().alert().getText();
	if(expectedMessage.equals(actualMessage)) {
        System.out.println("Matched");
    }
    else {
        System.out.println("Unmatched");
    }
	driver.switchTo().alert().accept();
	driver.close();
    throw new PendingException();
}

@When("^user enters invalid EmailID$")
public void user_enters_invalid_EmailID() throws Throwable {
	userinfo.setApplicantName("Bharathi");
	userinfo.setFirstName("Bharathi");
	userinfo.setFatherName("Krishna");
	userinfo.setDateofBirth("15-11-1997");
	userinfo.setGender("Female");
	userinfo.setMobileNo("9144667867");
	userinfo.setEmail("");
	userinfo.setConfirmButton();
    throw new PendingException();
}

@Then("^display 'Please fill the Email id'$")
public void display_Please_fill_the_Email_id() throws Throwable {
	String expectedMessage="Please fill the Email id";
	String actualMessage=driver.switchTo().alert().getText();
	if(expectedMessage.equals(actualMessage)) {
        System.out.println("Matched");
    }
    else {
        System.out.println("Unmatched");
    }
	driver.switchTo().alert().accept();
	driver.close();
    throw new PendingException();
}

@When("^user enters wrong EmailID$")
public void user_enters_wrong_EmailID() throws Throwable {
	userinfo.setApplicantName("Bharathi");
	userinfo.setFirstName("Bharathi");
	userinfo.setFatherName("Krishna");
	userinfo.setDateofBirth("15-11-1997");
	userinfo.setGender("Female");
	userinfo.setMobileNo("9144667867");
	userinfo.setEmail("bharu@");
	userinfo.setConfirmButton();
    throw new PendingException();
}

@Then("^display 'Please enter valid Email id'$")
public void display_Please_enter_valid_Email_id() throws Throwable {
	String expectedMessage="Please enter valid Email id";
	String actualMessage=driver.switchTo().alert().getText();
	if(expectedMessage.equals(actualMessage)) {
        System.out.println("Matched");
    }
    else {
        System.out.println("Unmatched");
    }
	driver.switchTo().alert().accept();
	driver.close();
    throw new PendingException();
}

@When("^user enters invalid Landline no$")
public void user_enters_invalid_Landline_no() throws Throwable {
	userinfo.setApplicantName("Bharathi");
	userinfo.setFirstName("Bharathi");
	userinfo.setFatherName("Krishna");
	userinfo.setDateofBirth("15-11-1997");
	userinfo.setGender("Female");
	userinfo.setMobileNo("9144667867");
	userinfo.setEmail("nikki1@gmail.com");
	userinfo.setLandLine("");
	userinfo.setConfirmButton();
    throw new PendingException();
}

@Then("^display 'please fill the landline no'$")
public void display_please_fill_the_landline_no() throws Throwable {
	String expectedMessage="please fill the landline no";
	String actualMessage=driver.switchTo().alert().getText();
	if(expectedMessage.equals(actualMessage)) {
        System.out.println("Matched");
    }
    else {
        System.out.println("Unmatched");
    }
	driver.switchTo().alert().accept();
	driver.close();
    throw new PendingException();
}

@When("^user enters invalid type of communication$")
public void user_enters_invalid_type_of_communication() throws Throwable {
	userinfo.setApplicantName("Bharathi");
	userinfo.setFirstName("Bharathi");
	userinfo.setFatherName("Krishna");
	userinfo.setDateofBirth("15-11-1997");
	userinfo.setGender("Female");
	userinfo.setMobileNo("9144667867");
	userinfo.setEmail("niiki1@gmail.com");
	userinfo.setCommunication("");
	userinfo.setConfirmButton();
    throw new PendingException();
}

@Then("^display 'Please select the Type of Communication$")
public void display_Please_select_the_Type_of_Communication() throws Throwable {
	String expectedMessage="Please select the Type of Communication";
	String actualMessage=driver.switchTo().alert().getText();
	if(expectedMessage.equals(actualMessage)) {
        System.out.println("Matched");
    }
    else {
        System.out.println("Unmatched");
    }
	driver.switchTo().alert().accept();
	driver.close();
    throw new PendingException();
}

@When("^user does not enter address$")
public void user_does_not_enter_address() throws Throwable {
	userinfo.setApplicantName("Bharathi");
	userinfo.setFirstName("Bharathi");
	userinfo.setFatherName("Krishna");
	userinfo.setDateofBirth("15-11-1997");
	userinfo.setGender("Female");
	userinfo.setMobileNo("9144667867");
	userinfo.setEmail("niiki1@gmail.com");
	userinfo.setCommunication("residence");
	userinfo.setResidenceAddres("");
	userinfo.setConfirmButton();
    throw new PendingException();
}

@Then("^display 'Please Enter Address'$")
public void display_Please_Enter_Address() throws Throwable {
	String expectedMessage="Please Enter Address";
	String actualMessage=driver.switchTo().alert().getText();
	if(expectedMessage.equals(actualMessage)) {
        System.out.println("Matched");
    }
    else {
        System.out.println("Unmatched");
    }
	driver.switchTo().alert().accept();
	driver.close();
    throw new PendingException();
}

@When("^user enters valid UserInformation$")
public void user_enters_valid_UserInformation() throws Throwable {
	userinfo.setApplicantName("Bharathi");
	userinfo.setFirstName("Bharathi");
	userinfo.setFatherName("Krishna");
	userinfo.setDateofBirth("15-11-1997");
	userinfo.setGender("Female");
	userinfo.setMobileNo("9144667867");
	userinfo.setEmail("niiki1@gmail.com");
	userinfo.setCommunication("residence");
	userinfo.setResidenceAddres("madireddystreet,paris");
	userinfo.setConfirmButton();
    throw new PendingException();
}

@Then("^displays 'Personal details are validated\\.!!!'$")
public void displays_Personal_details_are_validated() throws Throwable {
	driver.get("file:///C:/Users/srsathi/Desktop/details/UserInfoPayment/PaymentDetails.html");
    throw new PendingException();
}



}
