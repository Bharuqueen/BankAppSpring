package com.Dao;

import java.util.ArrayList;
import java.util.Iterator;

import com.bean.Order;

public class DataLayerClass {
	
//Using ArrayList we stored all the details in object
	ArrayList<Order> a= new ArrayList<Order>();
	public void ServiceOrder(Order bean)
	{
		a.add(bean);
		System.out.println(a);
		
	
	
	}
	

}
