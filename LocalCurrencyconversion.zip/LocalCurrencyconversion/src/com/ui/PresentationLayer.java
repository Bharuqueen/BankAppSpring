package com.ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;

import com.bean.Order;
import com.service.ServiceOrder;


public class PresentationLayer {
	

	public static void main(String[] arg)
	{
		//to take inputs from user.
		Scanner sc=new Scanner(System.in);
		
	//taking inputs from user.
		ArrayList<Order > a1=new ArrayList<Order>();
		Iterator it=a1.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
			Random rand=new Random();
			int id = (int)rand.nextInt(10);
			
				
		System.out.println("enter product");
		String product=sc.next();
		System.out.println("enter price");
	double price=sc.nextDouble();
		System.out.println("enter quantity");
		int quantity=sc.nextInt();
		System.out.println("enter amount");
		double amount=sc.nextDouble();
		System.out.println("enter charges");
		double charges=sc.nextDouble();
		//storing all the data in bean.
		Order bean= new Order(id,product,price,quantity,amount,charges);
		System.out.println(bean);
		//created object for ServiceOrder.
		ServiceOrder slc=new ServiceOrder();
	//by using object calling the method calculatorOrder.
		slc.calculateOrder(bean);
		//by using object calling the method SaveOrder.
		slc.SaveOrder(bean);
		}
	}




