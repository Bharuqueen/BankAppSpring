package com.customer.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.customer.bean.Customer;
import com.customer.dao.CustomerDao;
import com.customer.exception.CustomerException;
@Service
public class CustomerServiceImpl implements CustomerService {
	@Autowired
	CustomerDao customerdao;


	@Override
	public Customer getCustomerById(int id) throws CustomerException {
	try
	{
		return customerdao.findById(id).get();
	}
	catch (Exception ex)
	{
		throw new CustomerException(ex.getMessage());
	}
	}

	@Override
	public void deleteCustomer(int id) throws CustomerException {
		try
		{
			customerdao.deleteById(id);
		}
		catch(Exception e)
		{
			throw new CustomerException(e.getMessage());
		}
		
	}

	@Override
	public List<Customer> getAllCustomer() throws CustomerException {
		try
		{
			return customerdao.findAll();
		}
		catch(Exception e)
		{
			throw new CustomerException(e.getMessage());
		}
	}

	@Override
	public List<Customer> getCustomerByCity(String city) throws CustomerException {
		// TODO Auto-generated method stub
		try
		{
		return customerdao.getCustomerByCity(city);	
		}
		catch(Exception e) {
		throw new CustomerException(e.getMessage());
	}
	}

	@Override
	public List<Customer> updateCustomer(int id, Customer cust) throws CustomerException {
		try
		{
			Optional<Customer> optional=customerdao.findById(id);
			if(optional.isPresent())
			{
				Customer customer=optional.get();
				customer.setType(cust.getType());
				customer.setCity(cust.getCity());
				customerdao.save(customer);
				return getAllCustomer();
			}
			else
			{
				throw new CustomerException("Customer with Id"+id+" does not exist");	
			}
		}
			catch(Exception e) {
	            throw new CustomerException(e.getMessage());
			
	}
	}

	@Override
	public List<Customer> addCustomer(Customer cust) throws CustomerException {
		 try {
		        customerdao.save(cust);
		        return customerdao.findAll();
		        }catch(Exception e) {
		            throw new CustomerException(e.getMessage());
		        }
		        }
	}



