package com.cg;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		
		Employee emp = context.getBean(Employee.class);
		emp.setEid(100);
		emp.setName("Manju");
		emp.setSalary(30000);
		emp.setBu(" Software Engineer");
		emp.setAge(23);
	
		emp.getDetails(emp);
	}

}
