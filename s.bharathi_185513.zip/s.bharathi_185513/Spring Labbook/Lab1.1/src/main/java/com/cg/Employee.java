package com.cg;

public class Employee {
	
	private int eid,age;
	private String name,bu;
	private double salary;
	
	public Employee() {
		
	}
	public Employee(int eid, int age, String name, String bu, double salary) {
		super();
		this.eid = eid;
		this.age = age;
		this.name = name;
		this.bu = bu;
		this.salary = salary;
	}

	public int getEid() {
		return eid;
	}

	
	public void setEid(int eid) {
		this.eid = eid;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBu() {
		return bu;
	}

	public void setBu(String bu) {
		this.bu = bu;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public void getDetails(Employee emp) {
		System.out.println("Employee details:");
		System.out.println("---------------------");
		System.out.println("Employee Id: "+emp.eid);
		System.out.println("Employee Name: "+emp.name);
		System.out.println("Employee Salary: "+emp.salary);
		System.out.println("Employee BU: "+emp.bu);
		System.out.println("Employee Age: "+emp.age);
	}

}
