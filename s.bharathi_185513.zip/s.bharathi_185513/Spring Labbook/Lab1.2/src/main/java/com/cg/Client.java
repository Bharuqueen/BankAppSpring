package com.cg;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    ApplicationContext ac=new ClassPathXmlApplicationContext("bean.xml");
    
    Employee e=(Employee)ac.getBean("emp");
    		System.out.println(e);
	}

}