package com.cg;

public class Employee {

	private int employeeId;
	private String employeeName;
	private double salary;
	private SBU BusinessUnit;
	private SBU sbudetails;
	
public Employee(SBU sbudetails) {
	this.sbudetails=sbudetails;
}



public int getEmployeeId() {
	return employeeId;
}



public void setEmployeeId(int employeeId) {
	this.employeeId = employeeId;
}



public String getEmployeeName() {
	return employeeName;
}



public void setEmployeeName(String employeeName) {
	this.employeeName = employeeName;
}



public double getSalary() {
	return salary;
}



public void setSalary(double salary) {
	this.salary = salary;
}



public SBU getSbudetails() {
	return sbudetails;
}



public void setSbudetails(SBU sbudetails) {
	this.sbudetails = sbudetails;
}



@Override
public String toString() {
	return " Employee details \n -------------------\n Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", salary=" + salary + ", \n sbudetails="
			+ sbudetails + "]";
}
	
}
