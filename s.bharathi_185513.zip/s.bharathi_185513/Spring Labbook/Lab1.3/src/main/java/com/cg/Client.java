package com.cg;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    ApplicationContext ac=new ClassPathXmlApplicationContext("bean.xml");
    
        Employee e=(Employee)ac.getBean("emp");
    	
    	Employee e1=(Employee)ac.getBean("emp1");
    		SBU sbu=(SBU)ac.getBean("sbu");
    		System.out.println("SBU details:-------------");

    		System.out.println("sbuId= "+sbu.getSbuId() +", " + "sbuName= "+sbu.getSbuName() +",  "+ "sbuHead= " +sbu.getSbuHead());
    		System.out.println("Employee details:-------------");
    		System.out.println(sbu.getEmplist());
	}

}