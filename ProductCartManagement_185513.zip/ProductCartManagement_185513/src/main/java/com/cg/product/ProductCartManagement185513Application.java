package com.cg.product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductCartManagement185513Application {

	public static void main(String[] args) {
		SpringApplication.run(ProductCartManagement185513Application.class, args);
	}

}
