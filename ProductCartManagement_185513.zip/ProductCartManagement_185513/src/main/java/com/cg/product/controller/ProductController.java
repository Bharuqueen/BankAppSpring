package com.cg.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.cg.product.bean.Product;
import com.cg.product.exception.ProductException;
import com.cg.product.service.IProductService;


@RestController
public class ProductController {
	@Autowired
	IProductService productservice;

	@RequestMapping("/products")
	public List <Product> getAllProducts() throws ProductException
	{
		return productservice. getAllProducts();
	}
	
	/** Purpose:"Calling create productmethod by taking parameters from json object through postman**/
	/**parametertype:requestbody*/
	
	@RequestMapping(value="/product", method=RequestMethod.POST)
	public List<Product> CreateProduct(@RequestBody Product pro) throws ProductException{
		return productservice.CreateProduct(pro);
			}
	/*searching  the product by using id through postman  */
	/**parametertype:pathvariable*/
	
	@RequestMapping("/productsbyid/{id}")
	public Product getProductById(@PathVariable String id) throws ProductException{
	return productservice.getProductById(id);
}
	/*deleting the product by using id  */
	/**parametertype:pathvariable*/
	
	@DeleteMapping("/deleteproduct/{id}")	
	public ResponseEntity<String> deleteProduct(@PathVariable String id) throws ProductException {
	productservice.deleteProduct(id);
	return new ResponseEntity<String> ("Product with id "+id+" deleted",HttpStatus.OK);
	}
	/**updating product method by taking parameters from json object through postman using put method*/
	/**parametertype:pathvariable and requestbody*/
	
	@PutMapping("/products/{id}")
	public List <Product>  updateProduct(@PathVariable String id, @RequestBody Product pro) throws ProductException{
		return productservice. updateProduct(id, pro);
	}
	}

	
	


