import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IBookList } from './ibook-list';


@Injectable({
  providedIn: 'root'
})
export class BookDetailsService {

  private _url: string = "/assets/BookList.json";
  constructor(private http: HttpClient) { }

  getBooks(): Observable<IBookList[]>{
    return this.http.get<IBookList[]>(this._url);
  }
}
