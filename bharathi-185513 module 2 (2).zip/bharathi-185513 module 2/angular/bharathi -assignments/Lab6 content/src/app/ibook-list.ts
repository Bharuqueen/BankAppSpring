export interface IBookList {

    id: number,
    title: string,
    author: string, 
    yop: number
}
