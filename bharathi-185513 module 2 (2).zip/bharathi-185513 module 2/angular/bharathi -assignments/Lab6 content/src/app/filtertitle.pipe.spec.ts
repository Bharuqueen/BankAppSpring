import { FiltertitlePipe } from './filtertitle.pipe';

describe('FiltertitlePipe', () => {
  it('create an instance', () => {
    const pipe = new FiltertitlePipe();
    expect(pipe).toBeTruthy();
  });
});
