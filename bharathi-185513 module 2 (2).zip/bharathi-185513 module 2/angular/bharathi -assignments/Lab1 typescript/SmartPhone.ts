import {Mobile} from './Mobile';
export class SmartPhone extends Mobile{
    mobileType:string;
    constructor(name:string,cost:number,id:number,type:string){
        super(name,cost,id);
        this.mobileType=type;
    }
    printMobile()
    {  console.log(this.mobileName);
       console.log(this.mobileCost);
       console.log(this.mobileId);
       console.log(this.mobileType);

   }
}