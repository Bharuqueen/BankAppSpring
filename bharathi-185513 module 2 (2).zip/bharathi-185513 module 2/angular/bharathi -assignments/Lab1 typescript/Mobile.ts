export class Mobile{
    mobileId:number;
    mobileName:string;
    mobileCost:number;
    constructor(name:string,cost:number,id:number){
        this.mobileCost=cost;
        this.mobileId=id;
        this.mobileName=name;
    }
    printMobile()
     {  console.log(this.mobileName);
        console.log(this.mobileCost);
        console.log(this.mobileId);

    }
}